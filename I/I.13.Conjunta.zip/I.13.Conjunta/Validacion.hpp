#pragma once
int ingresarEntero();